# Win10_BrightnessSlider
this app puts a Monitor Brightness icon to on Taskbar Tray. So you can access it with 1 click.
targeting laptops. 

* **supported os**:  win7 , win8 , win10 , win11 
 

* **requirements**: 
  * .net4.6.2 framework.  (win7 may need to install)
  * for ddci monitors, ([make sure  ddci is enabled on monitor menu](https://github.com/blackholeearth/Win10_BrightnessSlider/blob/master/enable%20ddc-ci.jpg?raw=true)
)
  *  make sure you do install/update your graphic driver 
  
* **Note For VirusAlert, Source Code**: 
   * dont open issues about virus total trojan alert etc. if you dont trust dont use it.   

   * code version is  first working version (maybe 1.01). but **executable is always up to date**
   * old code published here is free to play.
   * uptodate code is my private intellectual property. coding effort made without any money, wont be put here.

-------------------
* **DONATE**: 

   bitcoin: 1A2CcDwWJ9MLuZaGUy5izNTZdWVnrQ9hWh

   bitcoin QR Code: 

   ![alt text](https://github.com/blackholeearth/Win10_BrightnessSlider/blob/master/send_bitcoinQR.png?raw=true)

--------------------

**Download Link**   [All Versions](https://github.com/blackholeearth/Win10_BrightnessSlider/releases)


#### Features

* Supports ddc/ci monitors 
* Seperate Sliders For Multiple Monitors
* Volume like Slider to Change Monitor Brightness
* Option to Run At Startup
* Ability to *"Rescan/Detect Monitor"* after a Monitor Plugged in/out

#### ScreenShots



![alt text](https://github.com/blackholeearth/Win10_BrightnessSlider/blob/master/ss1b.png?raw=true)

![alt text](https://github.com/blackholeearth/Win10_BrightnessSlider/blob/master/ss2.jpg?raw=true)

![alt text](https://github.com/blackholeearth/Win10_BrightnessSlider/blob/master/ss3.jpg?raw=true)


#### NOTES   
* if slider working. but suddenly (you plug/unplug monitor/MirrorScreen in any way) then screen act up weird for second.
 you CAN get error while trying to change birghtness, you gotta press "Detect monitor".  


#### ChangeLog 
at [release page](https://github.com/blackholeearth/Win10_BrightnessSlider/releases)  





